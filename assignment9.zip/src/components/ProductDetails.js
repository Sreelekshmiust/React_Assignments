import React from 'react';
import './ProductDetails.css';

function ProductDetails({ product }) {
  return (
    <div>
      <img src={product.image} alt={product.title} />
      <h2>{product.title}</h2>
      <p>{product.description}</p>
      <p>Price: ${product.price}</p>
      <p>Rating: {product.rating}</p>
    </div>
  );
}

export default ProductDetails;
