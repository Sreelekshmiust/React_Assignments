import React from 'react';

function Login(){
    return(
        <div>
            <h2>Login Page</h2>
        </div>
    )
}
export default Login;