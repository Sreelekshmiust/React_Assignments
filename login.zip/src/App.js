import React from 'react';
import {BrowserRouter as Router,Routes,Route,Link} from 'react-router-dom';
import Login from './components/Login';
import './App.css';
import Welcome from './components/Welcome';

function App() {
  return (
    <div className="App">
      <Router>
      <nav>
        <Link to="/login">Login</Link>
      </nav>
      <Routes>
        <Route path="/login" element={<Login/>}/>
        <Route path='/welcome' element={<Welcome/>}/>
      </Routes>
      </Router>
    </div>
  );
}

export default App;
