import {BrowserRouter as Router,Routes,Route,Link} from 'react-router-dom';
import Registration from './components/Registration.js';
import './App.css';


function App() {
  return (
    <div className="App">
      <Router>
      <nav>
        <Link to="/registration">Registration</Link>
      </nav>
        <Routes>
          <Route path="/registration" element={<Registration/>} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
