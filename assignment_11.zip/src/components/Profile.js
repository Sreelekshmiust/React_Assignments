import { useContext, useEffect, useReducer } from 'react';
import UserContext from '../UserContext';

const Profile = () => {
  const { username } = useContext(UserContext);

  const initialState = {
    loading: true,
    userData: null,
  };

  const reducer = (state, action) => {
    switch (action.type) {
      case 'SUCCESS':
        return {
          loading: false,
          userData: action.payload,
        };
      case 'ERROR':
        return {
          loading: false,
          userData: null,
        };
      default:
        return state;
    }
  };

  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('https://run.mocky.io/v3/832312b1-e05a-45fb-83dd-99d8f44eef46');
        const data = await response.json();
        dispatch({ type: 'SUCCESS', payload: data });
      } catch (error) {
        console.error('Error fetching data:', error);
        dispatch({ type: 'ERROR' });
      }
    };

    fetchData();
  }, []);

  return { username, ...state };
};

export default Profile;
