import './App.css';
import Crud from './components/Crud';

function App() {
  return (
    <div className="App">
      <Crud/>
    </div>
  );
}

export default App;
