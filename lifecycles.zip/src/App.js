import React from 'react';
import {BrowserRouter as Router, Routes, Route, Link} from 'react-router-dom';
import './App.css';
import LifecycleMethods from './LifeCycleMethods/LifeCycleMethods';

function Layout() {
  return (
    <div className="App">
      <Link to="/countchange">Counter</Link>
      <Routes>
        <Route path="/countchange" element={<LifecycleMethods />} />
      </Routes>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Layout />
    </Router>
  );
}

export default App;
