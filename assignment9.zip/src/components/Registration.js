import React from 'react';
import { useNavigate } from "react-router-dom";
import { TextField, Button, Grid } from '@mui/material';
import './Registration.css';

function Registration() {
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        navigate('/login');
    }

    return (
        <div className='Registration'>
            <form onSubmit={handleSubmit}>
                <h2>Registration</h2>
                <Grid container spacing={2}>
                    <Grid item xs={12}>
                        <TextField id="username" label="User Name" variant="outlined" fullWidth required />
                    </Grid>
                    <Grid item xs={6}>
                        <TextField id="firstname" label="First Name" variant="outlined" fullWidth required />
                    </Grid>
                    <Grid item xs={6}>
                        <TextField id="lastname" label="Last Name" variant="outlined" fullWidth required />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField id="password" label="Password" type="password" variant="outlined" fullWidth required />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField id="confirmPassword" label="Re-type Password" type="password" variant="outlined" fullWidth required />
                    </Grid>
                    <Grid item xs={12}>
                        <Button type="submit" variant="contained" color="primary" fullWidth>
                            Submit
                        </Button>
                    </Grid>
                </Grid>
                <p>Already have an account? <a href="/login">Login</a> </p>
            </form>
        </div>
    );
}

export default Registration;
