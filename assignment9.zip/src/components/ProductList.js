import React from 'react';
import { Typography } from '@mui/material';

function Product({ product }) {
  return (
    <div>
      <Typography variant="h5" gutterBottom>
        {product.title}
      </Typography>
      <img src={product.image} alt={product.title} style={{ width: '100%', maxWidth: '400px' }} />
      <Typography variant="body1" gutterBottom>
        {product.description}
      </Typography>
      <Typography variant="body1" gutterBottom>
        Price: ${product.price}
      </Typography>
    </div>
  );
}

export default Product;
