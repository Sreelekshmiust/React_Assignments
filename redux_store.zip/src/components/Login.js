import React from 'react';
import { useNavigate } from "react-router-dom";

const Login = ()=> {

    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        navigate('/dashboard');
    }

    return (
        <div className='Login'>
            <form onSubmit={handleSubmit}>
                <h2>Login</h2>
                <label for="username">User Name: </label>
                <input type='text' id='username' placeholder='Enter your Username' required /> <br /> <br />
                <label for="password">Password: </label>
                <input type="password" id="password" placeholder="Enter your Password" required /> <br /> <br />
                <button type="submit">Submit</button>
            </form>
        </div>
    );
}
export default Login; 