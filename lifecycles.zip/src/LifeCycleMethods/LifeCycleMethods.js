import React, { Component } from 'react';

class LifecycleMethods extends Component {
    constructor(props) {
        super(props);
        this.state = {
            count: 0
        };
        console.log('Constructor called');
    }

    componentDidMount() {
        console.log('Component did mount');
    }

    componentDidUpdate(prevProps, prevState) {
        console.log('Component did update');
    }

    componentDidCatch(error, info) {
        console.log('Component did catch an error');
    }

    shouldComponentUpdate(nextProps, nextState) {
        console.log('Should component update');
        return true;
    }

    componentWillUnmount() {
        console.log('Component will unmount');
    }

    render() {
        console.log('Render called');
        return (
            <div>
                <h1>Lifecycle Component</h1>
                <p>Count: {this.state.count}</p>
                <button onClick={() => this.setState({ count: this.state.count + 1 })}>
                    Increment Count
                </button>
            </div>
        );
    }
}

export default LifecycleMethods;