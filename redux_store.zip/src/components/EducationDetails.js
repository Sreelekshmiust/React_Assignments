import React, { useState } from 'react';
import { useSelector ,useDispatch } from 'react-redux';
import { addCertification } from './actions';

const EducationDetails = () => {
  const { tenth, higherSecondary, graduation, professionalCertifications } = useSelector(state => state);
  const dispatch = useDispatch();
  const [newCertification, setNewCertification] = useState('');

  const handleAddCertification = () => {
    dispatch(addCertification(newCertification));
    setNewCertification('');
  };

  return (
    <div>
      <h2>Education Details</h2>
      <p>10th: {tenth.instituteName} - CGPA: {tenth.CGPA}</p>
      <p>Higher Secondary: {higherSecondary.instituteName} - CGPA: {higherSecondary.CGPA}</p>
      <p>Graduation: {graduation.instituteName} - CGPA: {graduation.CGPA}</p>
      <h3>Professional Certifications</h3>
      <ul>
        {professionalCertifications.map((cert, index) => (
          <li key={index}>{cert}</li>
        ))}
      </ul>
      <div>
        <input type="text" value={newCertification} onChange={(e) => setNewCertification(e.target.value)} />
        <button onClick={handleAddCertification}>Add New</button>
      </div>
    </div>
  );
};

export default EducationDetails;
