import React from 'react';
import { useNavigate } from "react-router-dom";
import { TextField, Button, Grid } from '@mui/material';
import './Login.css';

function Login() {
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        navigate('/dashboard');
    }

    return (
        <div className='Login'>
            <form onSubmit={handleSubmit}>
                <h2>Login</h2>
                <Grid container spacing={2} justifyContent="center">
                    <Grid item xs={12}>
                        <TextField id="username" label="User Name" variant="outlined" fullWidth required />
                    </Grid>
                    <Grid item xs={12}>
                        <TextField id="password" label="Password" type="password" variant="outlined" fullWidth required />
                    </Grid>
                    <Grid item xs={12}>
                        <Button type="submit" variant="contained" color="primary" fullWidth>
                            Submit
                        </Button>
                    </Grid>
                </Grid>
                <p>Don't have an account? <a href="Registration">Register</a> </p>
            </form>
        </div>
    );
}

export default Login;
