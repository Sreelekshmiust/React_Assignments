import React, { useState } from 'react';
import './Registration.css';

function Registration() {
    const [formData, setFormData] = useState({
        name: '',
        age: '',
        company: ''
    });
    const [submitData,setSubmitData]=useState(false);

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(formData => ({
            ...formData,
            [id]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        setSubmitData(true);
    };

    return (
        <div className='Reg'>
            <div className="centered-box">
                <form className='Regform' onSubmit={handleSubmit}>
                    <h2>Registration Page</h2>
                    <div className="input-field">
                        <label htmlFor="name">Name: </label>
                        <input
                            type='text'
                            id='name'
                            placeholder='Enter your Name'
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                        <p>{formData.name}</p>
                    </div>
                    <div className="input-field">
                        <label htmlFor="age">Age: </label>
                        <input
                            type='text'
                            id='age'
                            placeholder='Enter your age'
                            value={formData.age}
                            onChange={handleChange}
                            required
                        />
                        <p>{formData.age}</p>
                    </div>
                    <div className="input-field">
                        <label htmlFor="company">Company: </label>
                        <input
                            type='text'
                            id='company'
                            placeholder='Enter your CompanyName'
                            value={formData.company}
                            onChange={handleChange}
                            required
                        />
                        <p>{formData.company}</p>
                    </div>
                    <br /><br />
                    <button type="submit">Submit</button>
                </form>
            </div>
            {submitData && (
        <div className='box'>
            <h2>Welcome</h2>
            <h4>Hi {formData.name}.You are {formData.age} and working in {formData.company}</h4>
        </div>)}
        </div>
    )
}

export default Registration;




