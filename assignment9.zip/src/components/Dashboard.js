// import React, { useState } from 'react';
// import ProductsData from './ProductsData';
// import ProductDetails from './ProductDetails';
// import './Dashboard.css';

// function Dashboard() {
//   const [selectedProduct, setSelectedProduct] = useState(null);

//   const handleProductClick = (product) => {
//     setSelectedProduct(product);
//   };

//   return (
//     <div className="dashboard">
//       <div className="product-list-sidebar">
//         {ProductsData.map(product => (
//           <button key={product.id} className="product-button" onClick={() => handleProductClick(product)}>
//             {product.title}
//           </button>
//         ))}
//       </div>
//       <div className="product-details-content">
//         {selectedProduct && <ProductDetails product={selectedProduct} />}
//       </div>
//     </div>
//   );
// }

// export default Dashboard;

import React, { useState } from 'react';
import ProductsData from './ProductsData';
import ProductDetails from './ProductDetails';
import { Grid, Button } from '@mui/material';
import './Dashboard.css';

function Dashboard() {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const handleProductClick = (product) => {
    setSelectedProduct(product);
  };

  return (
    <div className="dashboard">
      <Grid container>
        <Grid item xs={3} className="product-list-sidebar">
          {ProductsData.map(product => (
            <Button key={product.id} className="product-button" onClick={() => handleProductClick(product)} fullWidth>
              {product.title}
            </Button>
          ))}
        </Grid>
        <Grid item xs={9} className="product-details-content">
          {selectedProduct && <ProductDetails product={selectedProduct} />}
        </Grid>
      </Grid>
    </div>
  );
}

export default Dashboard;

