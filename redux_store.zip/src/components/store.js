import { configureStore } from "@reduxjs/toolkit";
import { persistReducer, persistStore } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

const initialState = {
  name: 'Sree',
  country: 'India',
  gender: 'Female',
  pan: 'ABC12NA',
  tenth: {
    instituteName: 'VHSS',
    CGPA: 9.5
  },
  higherSecondary: {
    instituteName: 'MGM',
    CGPA: 9.0
  },
  graduation: {
    instituteName: 'KTU',
    CGPA: 8.5
  },
  professionalCertifications: ['JAVA']
};

const ADD_CERTIFICATION = 'ADD_CERTIFICATION';

const Reducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_CERTIFICATION:
      return {
        ...state,
        professionalCertifications: [...state.professionalCertifications, action.payload],
      };
    default:
      return state;
  }
}

const persistConfig = {
  key: 'root',
  storage,
};

const persistedReducer = persistReducer(persistConfig, Reducer);

const store = configureStore({
  reducer: persistedReducer,
});

export const persistor = persistStore(store);

export default store;
