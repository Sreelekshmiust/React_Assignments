import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Login from './components/login';
import Registration from './components/registration';
import Profile from './components/profile';

function App() {
  return (
    <Router>
      <div className="App">
        <header>
          <p>
            <h2>Hello World!</h2>
          </p>
        </header>
        <nav>
          <ul>
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <Link to="/registration">Registration</Link>
            </li>
            <li>
              <Link to="/profile">Profile</Link>
            </li>
          </ul>
        </nav>
        <Routes>
          <Route path='/login' Component={Login} />
          <Route path='/registration' Component={Registration} />
          <Route path='/profile' Component={Profile} />
        </Routes>

      </div>
    </Router>
  );
}

export default App;
