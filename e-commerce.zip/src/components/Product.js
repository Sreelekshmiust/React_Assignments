import React,{useState} from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import './Product.css';

function Product(props) {

    const [heartFilled, setHeartFilled] = useState(false);

    const handleHeartClick = () => {
        setHeartFilled(!heartFilled);
      };

    const handleShare = () => {
        alert(`Product "${props.title}" has been shared`);
    };

    const handlePurchase = () => {
        alert(`Product "${props.title}" has been purchased`);
    };

    return (
        <div>
            <div className="product">
                <img src={props.image} alt={props.title} />
                <h2>{props.title}</h2>
                <p>{props.description}</p>
                <p>Price: ${props.price}</p>
                <p>Rating: {props.rating}</p>
                <div className="buttons">
                    <button className={`heart-button ${heartFilled ? 'filled':''}` } 
                    onClick={handleHeartClick}><FontAwesomeIcon icon={faHeart} /></button>
                    <button className="share-button" onClick={handleShare}>Share</button>
                    <button className="purchase-button" onClick={handlePurchase}>Purchase</button>
                </div>
            </div>
        </div>
    )
}
export default Product;