import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Profile from './components/Profile';
import EducationDetails from './components/EducationDetails';

function App() {
  return (
    <div className='container'>
      <Router>
        <Routes>
          <Route path="/" element={<Login/>} />
          <Route path="/dashboard" element={<Dashboard/>}  />
          <Route path="/profile" element={<Profile/>}  />
          <Route path="/education" element={<EducationDetails/>} />
        </Routes>
      </Router>
      </div>
  )}
export default App;
