import React, { Component } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Registration from './components/Registration';
import './App.css';

class App extends Component {
  render() {
      return (
          <div className="App">
              <Router>
                  <nav>
                      <Link to="/registration">Registration</Link>
                  </nav>
                  <Routes>
                      <Route path="/registration" element={<Registration />} />
                  </Routes>
              </Router>
          </div>
      );
  }
}

export default App;
