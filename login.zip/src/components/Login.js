import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './Login.css';

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isValidEmail, setIsValidEmail] = useState(true);
    const [isValidPassword, setIsValidPassword] = useState(true);
    const navigate = useNavigate();

    const handleValidation = (e) => {
        if (e.target.name === 'email') {
            const emailData = e.target.value;
            setEmail(emailData)
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            setIsValidEmail(emailRegex.test(emailData) || emailData === '');
        }
        if (e.target.name === 'password') {
            const passwordData = e.target.value;
            setPassword(passwordData)
            const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
            setIsValidPassword(passwordRegex.test(passwordData) || passwordData === '')
        }
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        if(isValidEmail && isValidPassword){
            navigate('/welcome');
        }
    }

    return (
        <div className="login-body">
            <div className="login">
            <form onSubmit={handleSubmit}>
                <h2>Login</h2>
                {!isValidEmail && (<span>
                    Enter a valid email
                </span>)} <br /><br />
                <label>Email: </label>
                <input
                    type='email'
                    name='email'
                    value={email}
                    onChange={handleValidation}
                    placeholder='Enter your Email'
                    required /> <br />
                <label>Password: </label>
                <input
                    type='password'
                    name='password'
                    value={password}
                    placeholder='Enter your Password'
                    onChange={handleValidation}
                    required /> <br />
                    {!isValidPassword && (<span>
                        Password must be at least 8 characters, including one uppercase letter, 
                        one lowercase letter, and one number
                </span>)} <br /><br />
                <button type="submit">Submit</button>
            </form>
            </div>
        </div>
    )
}
export default Login;
