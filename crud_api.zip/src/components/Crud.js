import React, { useEffect, useState } from "react";
import axios from 'axios';

const Crud = () => {
    const [todos, setTodo] = useState([]);
    const [newTitle, setNewTitle] = useState('');
    const [newStatus, setNewStatus] = useState('false');
    const [selectedTodoId, setSelectedTodoId] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('https://jsonplaceholder.typicode.com/todos?_limit=6');
                setTodo(response.data);
            }
            catch (error) {
                console.error("Error while fetching: ", error);
            }
        }

        fetchData();
    }, []);

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        try {
          if (selectedTodoId) {
            const response = await axios.put(`https://jsonplaceholder.typicode.com/posts/${selectedTodoId}`, {
              title: newTitle,
              completed: newStatus,
               
            });
            const updatedTodo = response.data;
            setTodo(todos.map(todo => todo.id === selectedTodoId ? updatedTodo : todo));
            setSelectedTodoId(null);
          } else {
            const response = await axios.post('https://jsonplaceholder.typicode.com/posts', {
              title: newTitle,
              completed: newStatus,
              userId: 1,
            });
            setTodo([...todos, response.data]);
          }
          setNewTitle('');
          setNewStatus('');
        } catch (error) {
          console.error('Error creating/updating todo:', error);
        }
      };
     
      const handleDelete = async (id) => {
        try {
          await axios.delete(`https://jsonplaceholder.typicode.com/posts/${id}`);
          setTodo(todos.filter(todo => todo.id !== id));
        } catch (error) {
          console.error('Error deleting post:', error);
        }
      };

    const handleEdit = (id, title, completed) => {
        setSelectedTodoId(id);
        setNewTitle(title);
        setNewStatus(completed);
    };
    return (
        <div>
            <h1>Todo</h1>
            <ul>
                {todos.map((todo) => (
                    <li key={todo.id}>
                        {todo.title} - {todo.completed}
                        <button onClick={() => handleEdit(todo.id, todo.title, todo.completed)}>Edit</button>
                        <button onClick={() => handleDelete(todo.id)}>Delete</button>
                    </li>
                ))}
            </ul>
            <h2>{selectedTodoId ? 'Edit Todo' : 'Create New Todo'}</h2>
            <form onSubmit={handleFormSubmit}>
                <input
                    type="text"
                    placeholder="Title"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                />
                <textarea
                    placeholder="Status"
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value)}
                />
                <button type="submit">{selectedTodoId ? 'Update' : 'Submit'}</button>
                {selectedTodoId && <button type="button" onClick={() => setSelectedTodoId(null)}>Cancel</button>}
            </form>
        </div>
    );
}
export default Crud;