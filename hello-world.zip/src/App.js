import React from 'react';
import './App.css';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import Login from './components/login';
import Registration from './components/registration';
import Profile from './components/profile';

function App() {
  return (
    <div className="App">
      <header>
        <p>
          <h2>Hello World!</h2>
        </p>
      </header>
      <Router>
        <Routes>
        <Route path='/login' Component={Login}/>
        <Route path='/registration' Component={Registration}/>
        <Route path='/profile' Component={Profile}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
