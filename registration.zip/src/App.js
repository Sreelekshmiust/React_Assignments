import './App.css';
import {BrowserRouter as Router,Routes,Route,Link} from 'react-router-dom';
import Registration from './components/Registration';

function App() {
  return (
    <div>
      <h2>Landing Page</h2>
    <div className="App">
      <Router>
      <nav>
        <Link to="/registration">Registration</Link>
      </nav>
        <Routes>
          <Route path="/registration" element={<Registration/>} />
        </Routes>
      </Router>
    </div>
    </div>
  );
}

export default App;
