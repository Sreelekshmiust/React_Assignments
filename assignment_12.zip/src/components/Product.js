import React, { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart } from '@fortawesome/free-solid-svg-icons';
import { Button, Card, CardActions, CardContent, CardMedia } from '@mui/material';
import './Product.css';

function Product(props) {

    const [heartFilled, setHeartFilled] = useState(false);

    const handleHeartClick = () => {
        setHeartFilled(!heartFilled);
    };

    const handleShare = () => {
        alert(`Product "${props.title}" has been shared`);
    };

    const handlePurchase = () => {
        alert(`Product "${props.title}" has been purchased`);
    };

    return (
        <Card className="product">
            <CardMedia
                component="img"
                height="140"
                image={props.image}
                alt={props.title}
            />
            <CardContent>
                <h2>{props.title}</h2>
                <p>{props.description}</p>
                <p>Price: ${props.price}</p>
                <p>Rating: {props.rating}</p>
            </CardContent>
            <CardActions>
                <Button
                    className={`heart-button ${heartFilled ? 'filled' : ''}`}
                    onClick={handleHeartClick}
                    startIcon={<FontAwesomeIcon icon={faHeart} />}
                >
                </Button>
                <Button className="share-button" onClick={handleShare}>Share</Button>
                <Button className="purchase-button" onClick={handlePurchase}>Purchase</Button>
            </CardActions>
        </Card>
    )
}
export default Product;
