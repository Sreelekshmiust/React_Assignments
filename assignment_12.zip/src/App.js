import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import Login from './components/Login';
import Registration from './components/Registration';
import ProductList from './components/ProductList';


function App() {
  return (
    <Router>
      <Routes>
        <Route path='/' element={<Login />} />
        <Route path='/register' element={<Registration />} />
        <Route path='/dashboard' element={<ProductList/>} />
      </Routes>
    </Router>
  );
}

export default App;
