import React from 'react';
import {Link} from 'react-router-dom';
import useUserProfile from './Profile';

const Dashboard = () => {
  const { username, loading, userData } = useUserProfile();

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <div>
          <h1>{username}'s Profile</h1>
          <p>Name: {userData.name}</p>
          <p>Country: {userData.country}</p>
          <p>Gender: {userData.gender}</p>
          <p>PAN: {userData.pan}</p>
          <Link to="/hooks">See the different hooks useState and useRef</Link>
        </div>
      )}
    </div>
  );
};

export default Dashboard;

