import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { UserProvider } from './UserContext';
import Dashboard from './components/Dashboard';
import Hooks from './components/Hooks';
import Login from './components/Login';
import Profile from './components/Profile';


const App = () => {
  return (
    <UserProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Login/>} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile/>} />
            <Route path="/hooks" element={<Hooks />} />
          </Routes>
        </Router>
    </UserProvider>
  );
};

export default App;
