import React from "react";

function Welcome(){

    return(
        <div>
            <h2>Welcome!</h2>
        </div>
    )
}
export default Welcome;