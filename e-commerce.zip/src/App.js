import React from 'react';
import './App.css';
import Product from './components/Product';
import ProductsData from './components/ProductsData';

function App() {
   const ProductDataComponent =ProductsData.map(product => 
    <Product 
    key={product.id}
    title={product.title}
    description={product.description}
    image={product.image}
    price={product.price}
    rating={product.rating}
  />
   )
  return (
    <div className="App">
      <h1>FreshHarvest</h1>
      <div className="products-container">
        {ProductDataComponent}
      </div>
    </div>
  );
}

export default App;
