import React from 'react';
import './Registration.css';

function Registration(){
return(
    <div className='Registration'>
        <form>
        <h2>Registration</h2>
        <label for="username">User Name: </label>
        <input type='text' id='username' placeholder='Enter your Username' required/> <br/> <br/>
        <label for="firstname">First Name: </label>
        <input type='text' id='firstname' placeholder='Enter your Firstname' required/>&nbsp; &nbsp;
        <label for="lastname">Last Name: </label>
        <input type='text' id='lastname' placeholder='Enter your Lastname' required/> <br/> <br/>
        <label for="phonenumber">Phone Number:</label>
            <select id="countrycode">
                <option value="india">+91</option>
                <option value="usa">+1</option>
                <option value="uk">+44</option>
            </select>
            <input type="text"/><br/> <br/>
            <label for="dob">Date of Birth: </label>
            <input type="date" id="dob" required/><br/> <br/>
            <label for="password">Password: </label>
            <input type="password" id="password" placeholder="Enter your Password" required/> <br/> <br/>
            <label for="confirmpassword">Re-type Password: </label> 
            <input type="password" id="confirmPassword" placeholder="Re-type your Password" required/> <br/> <br/>
            <label for="gender">Gender: </label> 
            <input type="radio" name="gender" id="male" value="Male" required/>Male
            <input type="radio" name="gender" id="female" value="Female"/>Female <br/> <br/>
            <input type="checkbox"/> I agree with Terms and Conditions <br/> <br/>
            <button type="submit">Submit</button>
            </form>
    </div>
);
}
export default Registration;