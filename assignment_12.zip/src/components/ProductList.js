import React from 'react';
import Product from './Product';
import './ProductList.css';
import ProductsData from './ProductData';

function ProductList() {
   const ProductDataComponent = ProductsData.map(product => 
    <Product 
        key={product.id}
        title={product.title}
        description={product.description}
        image={product.image}
        price={product.price}
        rating={product.rating}
    />
   );

   return (
      <div className="products-container">
        {ProductDataComponent}
      </div>
   );
}

export default ProductList;
