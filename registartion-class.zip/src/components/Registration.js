import React, { Component } from 'react';
import './Registration.css';

class Registration extends Component {
    constructor(props) {
        super(props);
        this.state = {
            formData: {
                name: '',
                age: '',
                company: ''
            },
            submitData: false,
        };
    }

    handleChange = (e) => {
        const { id, value } = e.target;
        this.setState(prevState => ({
            formData: {
                ...prevState.formData,
                [id]: value
            }
        }));
    };

    handleSubmit = (e) => {
        e.preventDefault();
        this.setState({ submitData: true });
    };

    render() {
        const { formData, submitData } = this.state;
        return (
            <div className='Reg'>
                <div className="centered-box">
                    <form className='Regform' onSubmit={this.handleSubmit}>
                        <h2>Registration Page</h2>
                        <div className="input-field">
                            <label htmlFor="name">Name: </label>
                            <input
                                type='text'
                                id='name'
                                placeholder='Enter your Name'
                                value={formData.name}
                                onChange={this.handleChange}
                                required
                            />
                            <p>{formData.name}</p>
                        </div>
                        <div className="input-field">
                            <label htmlFor="age">Age: </label>
                            <input
                                type='text'
                                id='age'
                                placeholder='Enter your age'
                                value={formData.age}
                                onChange={this.handleChange}
                                required
                            />
                            <p>{formData.age}</p>
                        </div>
                        <div className="input-field">
                            <label htmlFor="company">Company: </label>
                            <input
                                type='text'
                                id='company'
                                placeholder='Enter your CompanyName'
                                value={formData.company}
                                onChange={this.handleChange}
                                required
                            />
                            <p>{formData.company}</p>
                        </div>
                        <br /><br />
                        <button type="submit">Submit</button>
                    </form>
                </div>
                {submitData && (
                    <div className='box'>
                        <h2>Welcome</h2>
                        <h4>Hi {formData.name}.You are {formData.age} and working in {formData.company}</h4>
                    </div>
                )}
            </div>
        );
    }
}
export default Registration;