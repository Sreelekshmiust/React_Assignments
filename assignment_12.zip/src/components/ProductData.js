const ProductsData =
    [
        {
            "id": "1",
            "title": "Organic Strawberries",
            "type": "fruit",
            "description": "Juicy organic strawberries, handpicked from the farm",
            "image": "https://images.pexels.com/photos/1125122/pexels-photo-1125122.jpeg?auto=compress&cs=tinysrgb&w=600",
            "price": 19.99,
            "rating": 4.8
        },
        {
            "id": "2",
            "title": "Organic Broccoli",
            "type": "vegetable",
            "description": "Fresh organic broccoli, packed with vitamins and minerals",
            "image": "https://images.pexels.com/photos/3872433/pexels-photo-3872433.jpeg?auto=compress&cs=tinysrgb&w=600",
            "price": 3.99,
            "rating": 4.4
        },
        {
            "id": "3",
            "title": "Organic Spinach",
            "type": "vegetable",
            "description": "Fresh organic spinach, rich in nutrients and flavor",
            "image": "https://images.pexels.com/photos/2325843/pexels-photo-2325843.jpeg?auto=compress&cs=tinysrgb&w=600",
            "price": 12.49,
            "rating": 4.3
        },
        {
            "id": "4",
            "title": "Organic Bell Pepper",
            "type": "vegetable",
            "description": "Colorful organic bell peppers, crisp and flavorful",
            "image": "https://images.pexels.com/photos/2893635/pexels-photo-2893635.jpeg?auto=compress&cs=tinysrgb&w=600",
            "price": 4.99,
            "rating": 4.6
        },
        {
            "id": "5",
            "title": "Sweet Mangoes",
            "type": "fruit",
            "description": "Ripe and sweet mangoes, perfect for snacking or smoothies",
            "image": "https://images.pexels.com/photos/7543212/pexels-photo-7543212.jpeg?auto=compress&cs=tinysrgb&w=600",
            "price": 2.49,
            "rating": 4.7
        },
        {
            "id": "6",
            "title": "Organic Blueberries",
            "type": "fruit",
            "description": "Plump organic blueberries, bursting with flavor",
            "image": "https://images.pexels.com/photos/70862/pexels-photo-70862.jpeg?auto=compress&cs=tinysrgb&w=600",
            "price": 15.75,
            "rating": 4.6
        }
    ]
export default ProductsData;

